link to website:https://russian-lang-test.onrender.com/
This project is a scrapper website with authentication and admin functionalities.

Admin Details
Username: ilham
Password: 123
Installation
Prerequisites
Node.js installed on your system.
Setup Instructions
Clone the Repository

cd assignment4
Install Dependencies

npm install
node app.js
Start the Server

To start the server in production mode:
npm start
To start the server in development mode with nodemon:
nodemon app.js
Configuration


ChatGPT API 
Yandex Dictionary API (should use english words)

/quiz you shoud fully complete the quiz
/main page consist the api's and item that addded by admin
/admin crud operations with items
/login auth of user
Quizzes database consist 120 questions, and reading consist 4 text with at least 6 questions related


